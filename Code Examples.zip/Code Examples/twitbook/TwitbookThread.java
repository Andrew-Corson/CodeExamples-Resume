/*
 * Andrew Corson
 * acorson
 * 113572869
 * Section 0302
 * 
 * I pledge on my honor that I have not given or received any unauthorized
assistance on this assignment. 
 */

package twitbook;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

//Once started, a TwitbookThread will access an input stream from a webpage
//located at the given URL and will perform operations on its given
//Twitbook object.
//
//TwitbookThread has already been synchronized internally as to avoid 
//malfunctions in multi-threading
public class TwitbookThread implements Runnable {
	
	//Represents the client's connection to the page at the given url
	private URLConnection url;
	
	//The twitbook object that will be altered
	//
	//Also used as a lock in synchronization since it is common
	//among all threads
	private Twitbook twitbook;
	
	//Creates a connection the given url if possible
	public TwitbookThread(String url, Twitbook t) {
		try {
			this.url = new URL(url).openConnection();
		} catch (IOException e) {
			this.url = null;
		}
		
		twitbook = t;
	}
	
	//Uses URLConnection to scan an input stream and analyze HTML tables to 
	//perform functions on the thread's Twitbook object
	public void run() {
		Scanner s = null;
		String line = null;
		String[] commands = null;
		
		//Attempt to create input stream
		try {
			s = new Scanner(url.getInputStream());
		} catch (Exception e ) {
			//If any error occurred during connection or with retrieving the
			//input stream, the thread will end
			return;
		}
		
		//Read through page until table tag is found
		while(!s.nextLine().equals("<table>"));
		s.nextLine(); //Skip one more line for table headings
		
		//Loops through each table row and decides what to do.
		//
		//If getCommands returns an array of size 2, then it is implied 
		//that the line is trying to add a user.
		//If it returns an array of size 3, then it is trying create a friendship
		line = s.nextLine();
		while(!line.equals("</table>")) {
			commands = getCommands(line);
			//This is the only part of the thread that is synchronized because it is
			//the only section that requires a method to access information
			//from the network map
			if(commands.length == 2)
				synchronized(twitbook) {
					twitbook.addUser(commands[1]);
				}
			else
				synchronized(twitbook) {
					twitbook.friend(commands[1], commands[2]);
				}
			
			line = s.nextLine();				
		}
		
		//close the input stream
		s.close();
	
	}
	
	//Private helper method
	//Takes a String containing a table row HTML tag and returns a String array
	//where each element is the contents of an enclosed table data tag
	private String[] getCommands(String l) {
		//Removes the begining of the string before the operation
		l = l.substring(l.indexOf('a'));
		//Splits string between all table data tags
		String[] c = l.split("<td>");
		
		//Shortens the end of each element so that is is just the contents
		//of the tag
		for(int i = 0; i < c.length; i++)
			c[i] = c[i].substring(0, c[i].indexOf("<"));
		
		return c;
	}
}
