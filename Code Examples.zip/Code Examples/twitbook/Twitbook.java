/*
 * Andrew Corson
 * acorson
 * 113572869
 * Section 0302
 * 
 * I pledge on my honor that I have not given or received any unauthorized
assistance on this assignment. 
 */

package twitbook;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;

//The Twitbook class represents a social network with the ability to add
//members, manage friendships and perform tasks given by online webpages
public class Twitbook {
	
	//Represents the network of friends on this instance of Twitbook
	private Graph<String> network;
	
	//Default Constructor
	public Twitbook() {
		network = new Graph<String>();
	}
	
	//Adds the given username to the network
	//
	//returns true if successful
	//returns false if that user is already on Twitbook
  public boolean addUser(String name) {
  	if (!network.isVertex(name)) {
  		network.addVertex(name);
  		return true;
  	}
  	return false;
  }
  
  //Returns a collection of the usernames of all Twitbook users
  public Collection<String> getAllUsers() {
    return network.getVertices();
  }
  
  //Creates a friendship between the two given users and will add either of
  //the users if they are not already on Twitbook
  //
  //returns true if successful
  //returns false if friendship already exists of if a user is trying to
  //create a friendship with themselves
  public boolean friend(String user1, String user2) {
  	if (!network.isVertex(user1))
  		network.addVertex(user1);
  	if (!network.isVertex(user2))
  		addUser(user2);
  	
  	if(!(user1.equals(user2) || network.getEdgeCost(user1, user2) >= 0)) {
  		network.addEdge(user1, user2, 1);
  		network.addEdge(user2, user1, 1);
  		return true;
  	}
  	
  	return false;
  }
  
  //Returns a collection of the usernames of all of the given user's friends
  //
  //Will return an empty Collection if said user has no friends or
  //if the user does not exist
  public Collection<String> getFriends(String user) {
    if (!network.isVertex(user))
    	return new LinkedList<String>();
    return network.getNeighbors(user);
  }
  
  //Removes a friendship between user1 and user2
  //
  //returns true if successful
  //returns false if the friendship or either of the users never existed
  public boolean unfriend(String user1, String user2) {
  	if (network.getEdgeCost(user1, user2) < 0)
  		return false;
  	network.removeEdge(user1, user2);
  	network.removeEdge(user2,user1);
  	return true;
  }
  
  //Returns a list of all of the given user's friend's friends with the
  //exception of people that the user is already friends with
  //
  //Returns an empty collection is the user is not on Twitbook or
  //if they have no friends
  public Collection<String> peopleYouMayKnow(String user) {
    Collection<String> sug = new LinkedList<String>();
    
    if (!network.isVertex(user))
    	return sug;
    
    Collection<String> friends = getFriends(user);
    
    for (String friend : friends)
    	for (String f : getFriends(friend))
    		if (!(friends.contains(f) || f.equals(user)))
    			sug.add(f);
    
    return sug;    
  }
  
  //This method reads webpages from the given urls in order to add users
  //and create new friendships.
  //A new thread is created for each element in the array so that
  //they can be executed concurrently
  public void readFriendData(String[] urls) {
  	ArrayList<Thread> threads = new ArrayList<Thread>();
    for (int i = 0; i < urls.length; i++) {
    	threads.add(new Thread(new TwitbookThread(urls[i], this)));
    	threads.get(i).start();
    }
    
    for(Thread t : threads) {
    	try {
    		t.join();
    	} catch (InterruptedException e) {}
    }
    
    
  }

}
