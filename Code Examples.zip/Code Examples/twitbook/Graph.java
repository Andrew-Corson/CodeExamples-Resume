/*
 * Andrew Corson
 * acorson
 * 113572869
 * Section 0302
 * 
 * I pledge on my honor that I have not given or received any unauthorized
assistance on this assignment. 
 */

package twitbook;

import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;
import java.util.TreeMap;
import java.lang.IllegalArgumentException;
import java.util.NoSuchElementException;

//The Graph class is a representation of the graph abstract data type.
//It is a generic class with vertices that must be comparable.
//
//All methods throw a NullPointerException if an argument is null
public class Graph<V extends Comparable<V>> {
	
	//I used a TreeMap because it automatically iterates over its key set
	//in their natural ordering
	private TreeMap<V, TreeMap<V, Integer>> graph;
	
	//Default constructor that initializes the graph field
  public Graph() {
    graph = new TreeMap<V, TreeMap<V, Integer>>();
  }
  
  //addVertex creates a new vertex in the graph with no edges attached.
  //
  //Throws an IllegalArgumentException if the given vertex is
  //already in the graph
  public void addVertex(V vertex) throws IllegalArgumentException, 
  	NullPointerException {
  	//isVertex will throw the nullpointerException
  	if (isVertex(vertex))
  		throw new IllegalArgumentException("Vertex Already in Graph");
  	
    	graph.put(vertex, new TreeMap<V, Integer>());
  }
  
  //Returns whether or not the graph already contains a vertex equal to the
  //one given
  public boolean isVertex(V vertex) throws NullPointerException{
    if (vertex == null)
    	throw new NullPointerException("Vertex Cannot be Null");
    
    return graph.containsKey(vertex);
  }
  
  //Returns a collection of all the graph's vertices
  public Collection<V> getVertices() {
    return graph.keySet();
  }
  
  //Will remove the given vertex and all edges going to or from it.
  //
  //Throws a NoSuchElementException if the given vertex is not in the graph
  public void removeVertex(V vertex) throws NoSuchElementException, 
  	NullPointerException {
  	//isVertex throws nullPointerException
    if (!isVertex(vertex))
    	throw new NoSuchElementException("Vertex is not contained in "
    			+ "current object.");
    
    graph.remove(vertex);
    
    for (V v : graph.keySet())
    	graph.get(v).remove(vertex);
  }
  
  //Adds a directed edge from source to dest.
  //
  //Throws an IllegalargumentException if cost is less than 0 or if the
  //edge already exists in the graph
  public void addEdge(V source, V dest, int cost)
              throws IllegalArgumentException, NullPointerException {
    if (cost < 0)
    	throw new IllegalArgumentException("Weight cannot be negative");
    
    if (!isVertex(source))
    	addVertex(source);
    if (!isVertex(dest))
    	addVertex(dest);
    
    if (graph.get(source).containsKey(dest))
    	throw new IllegalArgumentException("Edge already exists in graph");
    
    graph.get(source).put(dest, cost);
  }
  
  //Returns the weight of the edge from source to dest.
  //
  //Returns -1 if the edge does not exist
  public int getEdgeCost(V source, V dest) throws NullPointerException{
  	//Throws the null pointer Exception
    if (!(isVertex(source) && isVertex(dest)))
    	return -1;
    
    Integer weight = graph.get(source).get(dest);
    return weight == null ? -1 : weight;
  }
  
  //Changes the weight of the given edge.
  //
  //Throws a NoSuchElementException if the the edge does not exist
  //Throws an IllegalArgumentException if the new weight is lest than 0
  public void changeEdgeCost(V source, V dest, int newCost)
              throws IllegalArgumentException, NoSuchElementException,
  						NullPointerException {
    if (newCost < 0)
    	throw new IllegalArgumentException("Weight cannot be less than 0");
    
    if (getEdgeCost(source, dest) == -1)
    	throw new NoSuchElementException("Either source, dest or the edge"
    			+ " bettween them does not exist in this graph.");
    
    graph.get(source).put(dest, newCost);
  }
  
  //Removes the edge that went from source to dest.
  //
  //Throws a NoSuchElementExceptionn if the edge does not exist in the graph.
  public void removeEdge(V source, V dest) throws NoSuchElementException,
  																								NullPointerException {
    if (getEdgeCost(source, dest) == -1)
    	throw new NoSuchElementException("Eight source, dest or the edge"
    			+ " bettween them does not exist is this graph.");
    
    graph.get(source).remove(dest);
  }
  
  //Returns a collection of all the vertices that the given vertex has
  //an edge pointing towards
  //
  //Throws an IllegalArgumentException if the given vertex is not in the graph
  public Collection<V> getNeighbors(V vertex) throws IllegalArgumentException,
  																									 NullPointerException {
    if (!isVertex(vertex))
    	throw new IllegalArgumentException("Vertex is not in this graph.");
    
    return graph.get(vertex).keySet();
  }
  
  //Returns all vertices that have edges pointing at the given vertex
  //
  //Throws an IllegalArgumentException if the given vertex is not in the graph
  public Collection<V> getPredecessors(V vertex)
                       throws IllegalArgumentException, NullPointerException {
    if (!isVertex(vertex))
    	throw new IllegalArgumentException("Vertex is not in this graph.");
    
    LinkedList<V> preds = new LinkedList<V>();
    for (V v : graph.keySet())
    	if (graph.get(v).containsKey(vertex))
    		preds.add(v);
    
    return preds;
  }
  
  //Returns true if ever vertex on the graph has an edge pointing towards
  //every other vertex on the graph besides itself
  public boolean isClique() {
  	for (V vertex : graph.keySet()) {
  		for (V n : graph.keySet())
  			if (!(graph.get(vertex).containsKey(n) || n.equals(vertex)))
  				return false;
  	}
  	
    return true;
  }
  
  //Returns the length of the shortest path from sourceVertex to destVetex
  //It also changes shortestPath into a list of vertices that shows the
  //shortest path from source to dest
  //
  //Returns -1 if there is no path from the source to the destination.
  //
  //Throws an IllegalArgumentException if either of the given vertices
  //are not in the graph
  public int dijkstra(V sourceVertex, V destVertex, List<V> shortestPath)
             throws IllegalArgumentException, NullPointerException {
  	
    if (!(isVertex(sourceVertex) && isVertex(destVertex)))
    	throw new IllegalArgumentException("Either the source or the "
    			+ "destination vertex is not contained in this graph.");
    
    //List of vertices in their natural ordering (for indexing purposes)
    LinkedList<V> vertices = new LinkedList<V>();
    for (V v : graph.keySet())
    	vertices.add(v);
    
    //List of currently processed vertices
    LinkedList<V> processed = new LinkedList<V>();
    
    //Stores the min cost from the source to each vertex (parallel to vertices)
    int[] minCost = new int[vertices.size()];
    Arrays.fill(minCost, Integer.MAX_VALUE);
    minCost[vertices.indexOf(sourceVertex)] = 0;
    
    //Vertex preceding it on its path to source
    LinkedList<V> preds = new LinkedList<V>();
    //By default, all vertices' predecessors are null
    for(int i = 0; i < vertices.size(); i++)
    	preds.add(null);
    
    //Utility queue that adds to processed because the algorithm only works
    //when the vertex to be processed is at the end of the list
    LinkedList<V> waitList = new LinkedList<V>();
    waitList.add(sourceVertex);
    
    //While there are still vertices waiting to be processed
    while (waitList.size() > 0) {
    	
    	processed.add(waitList.poll());
    	
    	//Loop through each neighbor of the vertex being processed
    	for (V v: getNeighbors(processed.peekLast())) {
    		//If this vertex hasn't already been processed
    		if (!processed.contains(v)) {
    			//and if the distance from the current vertex to its neighbor
    			//plus its current minCost is less than the neighbors current
    			//minCost
    			if (minCost[vertices.indexOf(v)] > 
    					(minCost[vertices.indexOf(processed.peekLast())] + 
    					 getEdgeCost(processed.peekLast(), v))) {
    				//Give the neighbor a new minCost along the new path	
    				minCost[vertices.indexOf(v)] = 
    					minCost[vertices.indexOf(processed.peekLast())] + 
     					getEdgeCost(processed.peekLast(), v);
    				//and record the shortest path to the neighbor from the source
    				preds.add(vertices.indexOf(v), processed.peekLast());
    			}
    		}
    	}//end of for loop
    	
    	//Adds any new vertices to the wait list that were found
    	//with this vertex
    	for (V v : getNeighbors(processed.peekLast()))
    		if (!processed.contains(v))
    			waitList.add(v);
    			
    }//end of while loop
    
    //At this point we can assume preds has the necessary information to
    //find the shortest path from source to dest
    
    //follow the path from the destination back to the source using the
    //preds lists
    V tracking = destVertex;
    Stack<V> path = new Stack<V>();
    path.push(tracking);
    while (!(tracking == null || tracking.equals(sourceVertex))) {
    	tracking = preds.get(vertices.indexOf(tracking));
    	path.push(tracking);
    }
    
    //the path from the destination will be null if there is no path
    //from the source to it
    if(path.peek() == null)
    	return -1;
    
    //Since the above loop traveled the path backwards, the vertices were
    //added into a stack and are popped back out in the correct order
    //in this loop
    while (path.size() > 0)
    	shortestPath.add(path.pop());
    
    //total the distance of the shortest path
    int distance = 0;
    for(int i = 0; i < shortestPath.size() - 1; i++)
    	distance += getEdgeCost(shortestPath.get(i), shortestPath.get(i + 1));
    
    return distance;
  }
}
